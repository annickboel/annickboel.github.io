<?php
/**
 * GamerPrices plugin Adminitration page
 *
 * @package GamerPrices
 * @since 1.0
 */
class GP_Admin {
	const NONCE = 'gamerprices-update-partner-key';
	private static $initiated = false;
	private static $notices   = array();

	/**
     * Init the class
     *
     * @since    1.0
     */
	public static function init() {
		if (! self::$initiated) {
			self::init_hooks ();
		}
	}

 	/**
     * Register this class with the WordPress API
     *
     * @since    1.0
     */
	public static function init_hooks() {
		self::$initiated = true;
		//Load plugin text domain
		load_plugin_textdomain( 'gamerprices', FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
		add_action( 'admin_menu', array( 'GP_Admin', 'admin_menu' ), 5 ); 

		//Load Admin page stylesheet
		add_action( 'admin_enqueue_scripts', array( 'GP_Admin', 'load_custom_wp_admin_style' ));
		
	}
	
	/**
	 * Add Admin page custom styles
	 *
	 * @since    1.0
	 */
   	public static function load_custom_wp_admin_style($hook) {
        if ($hook != 'settings_page_gamerprices-partner-key-config') {
                return;
        }
        wp_enqueue_style( 'gamerprices_css', plugins_url('_inc/css/gamerprices.css', __FILE__) );
	}


	/**
	 * Add Admin Menu
	 *
	 * @since    1.0
	 */
	public static function admin_menu() {
		$hook = add_options_page ( 
			__ ( 'GamerPrices', 'gamerprices' ), 
			__ ( 'GamerPrices', 'gamerprices' ), 
			'manage_options', 
			'gamerprices-partner-key-config', 
			array (
				'GP_Admin',
				'display_config_page' 
			)
		);
	}

	/**
	 * Save or upadate admin page options
	 *
	 * @since    1.0
	 */
	public static function handle_config_option($option_key) {
		//Set defaut config values
		$partner_option_default_value='';
		$width_option_default_value='100%';
		$height_option_default_value='300';
		$scrolling_option_default_value='auto';
		$style_option_default_value='border:none;';

		//Load config options from database to display admin page
		//Display default value when the option has not been defined
		$option_value=get_option($option_key);
		switch ($option_key) {
			case GamerPrices::$partner_option_key:
				$option_value = empty($option_value) ? $partner_option_default_value : $option_value;
				break;	
			case GamerPrices::$width_option_key:
				$option_value = empty($option_value) ? $width_option_default_value : $option_value;
				break;	
			case GamerPrices::$height_option_key:
				$option_value = empty($option_value) ? $height_option_default_value : $option_value;
				break;	
			case GamerPrices::$scrolling_option_key:
				$option_value = empty($option_value) ? $scrolling_option_default_value : $option_value;
				break;	
			case GamerPrices::$style_option_key:
				$option_value = empty($option_value) ? $style_option_default_value : $option_value;
				break;			
		}
		
		//Make sure that a user was referred from another admin page.
		if ((isset($_POST [$option_key])) && (check_admin_referer( self::NONCE))) {
			if (empty ( $_POST [$option_key] )) {
				Gamerprices::update_option ( $option_key, NULL );
				$option_value=$partner_option_default_value;
			}
            else {
            	if ($_POST [$option_key]!= $option_value) {
            		GamerPrices::update_option( $option_key, $_POST [$option_key]);
            		$option_value=get_option($option_key);
            	}
            }
		}
		return $option_value;
	}

	/**
	 * Display Configuration Page
	 * @since    1.0
	 */
	public static function display_config_page() {
		//Check user capability to manage options
		if (function_exists ( 'current_user_can' ) && ! current_user_can ( 'manage_options' )) {
			die ( 'Unauthorized' );
		}

		$partner_option_value='';
		$width_option_value='100%';
		$height_option_value='300';
		$scrolling_option_value='auto';
		$style_option_value='border:none;';

		$partner_option_value=GP_Admin::handle_config_option(GamerPrices::$partner_option_key);
		$width_option_value=GP_Admin::handle_config_option(GamerPrices::$width_option_key);
		$height_option_value=GP_Admin::handle_config_option(GamerPrices::$height_option_key);
		$scrolling_option_value=GP_Admin::handle_config_option(GamerPrices::$scrolling_option_key);
		$style_option_value=GP_Admin::handle_config_option(GamerPrices::$style_option_key);
		
		GamerPrices::view ( 'admin', 'config', 
			compact('partner_option_value', 
				     'width_option_value',
				     'height_option_value',
				     'scrolling_option_value',
				     'style_option_value'));
	}

	/**
	 * Return the Admin page URL
	 * @since    1.0
	 */
	public static function get_page_url( ) {
		return add_query_arg ( array (
			'page' => 'gamerprices-partner-key-config' 
		), admin_url ( 'options-general.php' ) );
	}

}

?>