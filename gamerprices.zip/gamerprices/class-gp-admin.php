<?php
/**
 * GamerPrices plugin Adminitration page
 *
 * @package GamerPrices
 * @since 1.0
 */
class GP_Admin {
	const NONCE = 'gamerprices-update-partner-key';
	private static $initiated = false;
	private static $notices   = array();

	/**
     * Init the class
     *
     * @since    1.0
     */
	public static function init() {
		if (! self::$initiated) {
			self::init_hooks ();
		}
	}

 	/**
     * Register this class with the WordPress API
     *
     * @since    1.0
     */
	public static function init_hooks() {
		self::$initiated = true;
		load_plugin_textdomain( 'gamerprices', FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
		add_action( 'admin_menu', array( 'GP_Admin', 'admin_menu' ), 5 ); 
	}

	/**
	 * Add Admin Menu
	 *
	 * @since    1.0
	 */
	public static function admin_menu() {
		$hook = add_options_page ( 
			__ ( 'GamerPrices', 'gamerprices' ), 
			__ ( 'GamerPrices', 'gamerprices' ), 
			'manage_options', 
			'gamerprices-partner-key-config', 
			array (
				'GP_Admin',
				'display_config_page' 
			)
		);
	}

	/**
	 * Display Configuration Page
	 * @since    1.0
	 */
	public static function display_config_page() {
		//Check user capability to manage options
		if (function_exists ( 'current_user_can' ) && ! current_user_can ( 'manage_options' )) {
			die ( 'Unauthorized' );
		}
		$partner_key='';

		//Load Partner key is the parner has been configured
		if (Gamerprices::has_partner_key()) {
			$partner_key=Gamerprices::get_partner_key();
		}

		//Make sure that a user was referred from another admin page.
		if ((isset($_POST ['partner_key'])) && (check_admin_referer( self::NONCE))) {
			if (empty ( $_POST ['partner_key'] )) {
				if (GamerPrices::has_partner_key ()) {
					//Save NULL Partner key and set incorrect_partner_key
					GamerPrices::update_partner_key ( NULL );
					$partner_key='';
				}
			}
            else {
            	if ($_POST ['partner_key']!= GamerPrices::get_partner_key ()) {
            		GamerPrices::update_partner_key ( $_POST ['partner_key'] );
            		$partner_key=$_POST ['partner_key'];
            	}
            }
		}
		GamerPrices::view ( 'admin', 'config', compact('partner_key'));
	}

	/**
	 * Return the Admin page URL
	 * @since    1.0
	 */
	public static function get_page_url( ) {
		return add_query_arg ( array (
			'page' => 'gamerprices-partner-key-config' 
		), admin_url ( 'options-general.php' ) );
	}

}

?>