<h1><?php esc_html_e( 'Gamerprices Settings Page' , 'gamerprices');?></h1>

<form action="<?php echo esc_url( GP_Admin::get_page_url() ); ?>"  method="POST">
    <label for="partner_key"><?php esc_html_e( 'Partner' , 'gamerprices');?>:</label>
    <?php wp_nonce_field( 'gamerprices-update-partner-key' ); ?>
    <input type="text" name="partner_key" id="partner_key" value="<?php echo $partner_key; ?>">
    <input type="submit" value="<?php esc_html_e( 'Save' , 'gamerprices');?>" class="button button-primary button-large">
</form>