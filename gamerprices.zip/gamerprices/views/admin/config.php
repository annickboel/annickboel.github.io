
<div id="gamerprices-plugin-container">
	<div class="gamerprices-masthead">
		<?php esc_html_e( 'Gamerprices Settings Page' , 'gamerprices');?>
	</div>
	<div class="gamerprices-form-container">
		<form class="gamerprices-form" action="<?php echo esc_url( GP_Admin::get_page_url() ); ?>"  method="POST">
			<?php wp_nonce_field( 'gamerprices-update-partner-key' ); ?>
			<div class='gamerprices-form-item'>
				<span class="gamerprices-form-left">
		    		<label for="partner_key"><?php esc_html_e( 'Partner' , 'gamerprices');?>:</label>
		    	</span>
		    	<span class="gamerprices-form-right">
		    		<input type="text" name="gamerprices_partner_option" id="gamerprices_partner_option" value="<?php echo $partner_option_value; ?>">
		    	</span>
			</div>
			<div class='gamerprices-form-item'>
				<span class="gamerprices-form-left">
		    		<label for="width"><?php esc_html_e( 'Width' , 'gamerprices');?>:</label>
		    	</span>
		    	<span class="gamerprices-form-right">
		    		<input type="text" name="gamerprices_width_option" id="gamerprices_width_option" value="<?php echo $width_option_value; ?>">
		    	</span>
		    </div>
		    <div class='gamerprices-form-item'>
		    	<span class="gamerprices-form-left">
		    		<label for="height"><?php esc_html_e( 'Height' , 'gamerprices');?>:</label>
		    	</span>
		    	<span class="gamerprices-form-right">
		    		<input type="text" name="gamerprices_height_option" id="gamerprices_height_option" value="<?php echo $height_option_value; ?>">
		    	</span>
		    </div>
		    <div class='gamerprices-form-item'>
		    	<span class="gamerprices-form-left">
		    		<label for="scrolling"><?php esc_html_e( 'Scrolling' , 'gamerprices');?>:</label>
		    	</span>
		    	<span class="gamerprices-form-right">
			    	<select name="gamerprices_scrolling_option" id='gamerprices_scrolling_option'>
    					<option value="auto" <?php if ( $scrolling_option_value == 'auto' ) echo 'selected="selected"'; ?>>auto</option>
    					<option value="yes" <?php if (  $scrolling_option_value == 'yes' ) echo 'selected="selected"'; ?>>yes</option>
    					<option value="no" <?php if (  $scrolling_option_value == 'no' ) echo 'selected="selected"'; ?>>no</option>
					</select>
				</span>
		    </div>
	 		<div class='gamerprices-form-item'>
	 			<span class="gamerprices-form-left">
		    		<label for="style"><?php esc_html_e( 'Style' , 'gamerprices');?>:</label>
		    	</span>
		    	<span class="gamerprices-form-right">
		    		<textarea name="gamerprices_style_option" id="gamerprices_style_option" rows="3" cols="30"><?php echo $style_option_value; ?></textarea>
		    	</span>
		    </div>

		    <div class='gamerprices-form-submit'>
		    	<input  type="submit" value="<?php esc_html_e( 'Save' , 'gamerprices');?>" class="button button-primary button-large">
		    </div>
		</form>
	</div>
</div>
