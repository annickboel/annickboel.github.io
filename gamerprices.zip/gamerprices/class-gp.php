<?php
/**
 * Gamer Prices class
 *
 *
 * @package GamerPrices
 * @since 1.0
 */
class GamerPrices {
	public static $platforms_available = array('pc', 'ps4', 'xboxone', 'wiiu', 'ps3', 'xbox360', 'nintendods', 'psvita', 'wii', 'psp', 'linux', 'mac');
	public static $partners_available = array('xboxygen');

	const PARTNER_KEY = 'gamerprices_partner_key';
	
	/**
	 * Activation
 	 * @since 1.0
	 */
	public static function plugin_activation() {
	}
	
	/**
	 * Deactivation
	 * @since 1.0
	 */
	public static function plugin_deactivation() {
	}


	/**
	 * Ckeck if the Partner key has been defined
	 * @return true if Partner key existed
	 */
	public static function has_partner_key() {
		return self::get_partner_key () !== FALSE;
	}
	
	/**
	 * Get Partner Key value
	 * @return the Partner Key
	 */
	public static function get_partner_key() {
		return get_option ( self::PARTNER_KEY );
	}
	
	/**
	 * Update Partner Key
	 * @param string $key
	 */
	public static function update_partner_key( $key ) {
		if (is_null ( $key )) {
			delete_option ( self::PARTNER_KEY );
		} else {
			update_option ( self::PARTNER_KEY, $key );
		}
	}

	/**
	 * Verify Partner key
	 * @param string $key
	 * @return boolean 
	 */
	public static function verify_partner_key( $key ) {
		return in_array($key, self::$partners_available);
	}

	/**
	 * Include view file
	 * 
	 * @param string $dir
	 * @param string $name
	 * @param array $args
	 */
	public static function view( $dir, $name, array $args = array() ) {
		foreach ( $args as $key => $val ) {
			$$key = $val;
		}
		load_plugin_textdomain ( 'gamerprices' );
		$file = GAMERPRICES__PLUGIN_DIR . 'views/' . $dir . '/' . $name . '.php';
		include $file;
	}

}

?>