<?php
/**
 * Gamer Prices class
 *
 *
 * @package GamerPrices
 * @since 1.0
 */
class GamerPrices {
	public static $platforms_available = array('pc', 'ps4', 'xboxone', 'wiiu', 'ps3', 'xbox360', 'nintendods', 'nswitch', 'psvita', 'wii', 'psp', 'linux', 'mac');
	public static $partners_available = array('xboxygen');

	public static $partner_option_key = 'gamerprices_partner_option';
	public static $width_option_key = 'gamerprices_width_option';
	public static $height_option_key = 'gamerprices_height_option';
	public static $scrolling_option_key = 'gamerprices_scrolling_option';
	public static $style_option_key = 'gamerprices_style_option';
	
	/**
	 * Activation
 	 * @since 1.0
	 */
	public static function plugin_activation() {
		update_option(Gamerprices::$width_option_key, '100%');
		update_option(Gamerprices::$height_option_key, '300');
		update_option(Gamerprices::$scrolling_option_key, 'auto');
		update_option(Gamerprices::$style_option_key, 'border:none;');
	}

	/**
	 * Deactivation
	 * @since 1.0
	 */
	public static function plugin_deactivation() {
		delete_option(Gamerprices::$partner_option_key);
		delete_option(Gamerprices::$width_option_key);
		delete_option(Gamerprices::$height_option_key, '300');
		delete_option(Gamerprices::$scrolling_option_key, 'auto');
		delete_option(Gamerprices::$style_option_key, 'border:none;');
	}

	/**
	 * Get option value
	 * @param $option_key The option key
	 * @return the option value
	 */
	public static function get_option($option_key) {
		switch ($option_key) {
    		case self::$partner_option_key:
        		return get_option ( self::$partner_option_key );
        		break;
        	case self::$width_option_key:
        		return get_option ( self::$width_option_key );
        		break;
        	case self::$height_option_key:
        		return get_option ( self::$height_option_key );
        		break;
        	case self::$scrolling_option_key:
        		return get_option ( self::$scrolling_option_key );
        		break;
        	case self::$style_option_key:
        		return get_option ( self::$style_option_key );
        		break;
		}
	}
	
	/**
	 * Get option value
	 * @param $option_key The option key
	 * @return the option value
	 */
	public static function update_option( $option_key, $option_value) {
		if ($option_value==NULL) {
			delete_option($option_key);
		}
		else {
			update_option($option_key, $option_value);
		}
	}

	/**
	 * Include view file
	 * 
	 * @param string $dir
	 * @param string $name
	 * @param array $args
	 */
	public static function view( $dir, $name, array $args = array() ) {
		foreach ( $args as $key => $val ) {
			$$key = $val;
		}
		load_plugin_textdomain ( 'gamerprices' );
		$file = GAMERPRICES__PLUGIN_DIR . 'views/' . $dir . '/' . $name . '.php';
		include $file;
	}

}

?>