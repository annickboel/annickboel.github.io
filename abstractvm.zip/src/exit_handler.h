/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Function to handle the exit instruction
*/
#ifndef H_EXIT_HANDLER
#define H_EXIT_HANDLER

int handle_exit(const char *, const char *);

#endif