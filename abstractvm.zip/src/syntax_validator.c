/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Functions needed to valiadate syntax
*/

#include "syntax_validator.h"
#include "instruction_validator.h"
#include "type_validator.h"
#include "memory_utils.h"
#include "string_utils.h"
#include "error_utils.h"

int check_valid_syntax(t_instruction *instruction) {

	if (!check_known_instruction(instruction)) {
		print_error(UNKNOWN_INSTRUCTION_ERROR, instruction->name);
		return (-1);
	}
	if (!check_valid_type(instruction)) {
		print_error(INVALID_TYPE_ERROR, instruction->arg_type);
		return (-1);
	}
	return (0);
}





