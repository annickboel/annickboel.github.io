/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Functions to handle the stack
*/
#ifndef H_STACK_HANDLER
#define H_STACK_HANDLER

int handle_push(const char*, const char *);
int handle_pop(const char*, const char *);
int handle_dump(const char*, const char *);
int handle_print(const char*, const char *);
int handle_assert(const char*, const char *);

#endif