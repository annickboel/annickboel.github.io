/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Program entry point
*/

#include "error_utils.h"
#include "program_interpretor.h"
#include "memory_utils.h"

int main(int argc, char **argv) {

	extern char *filename;
	extern char *file_buffer;
	extern t_stack* stack_buffer;
	extern t_program *prog_buffer;
	int rc;

	rc = 0;
	if (argc < 2) {
        usage();
        rc = -1;
        return (rc);
    }
    filename = argv[1];
    rc = allocate_memory();
    if (rc < 0) {
    	print_error(MEMORY_ALLOCATION_ERROR, "");
		return (rc);
	}
    rc = interpret_program();
	if (rc < 0) {
		return (rc);
	}
	free_memory();
	return (rc);
}
