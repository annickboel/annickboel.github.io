/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Conversion functions
*/
#ifndef H_CONVERSION_UTILS
#define H_CONVERSION_UTILS


int string2int(char *);
char int2char(int);

int int8_to_char(char *str);
char * get_greatest_precision(const char *, const char *);

#endif