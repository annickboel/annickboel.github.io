/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Helper functions to parse the program
**      	. Empty lines and comment lines are removed
**      	. Comment is removed if present in a line
**      	. An instruction structure is initialized for each valid line
*/

#include "program_parser.h"
#include "program_loader.h"
#include "string_utils.h"
#include "memory_utils.h"
#include "error_utils.h"
#include "line_validator.h"
#include "instruction_validator.h"
#include "syntax_validator.h"
#include <stdlib.h>

static t_program* program;
int parse_program(void) {

	char line[1024];
	int i;
	int j;
	int rc;
	int flag_exit;
	t_instruction *instruction;
	extern 	char *file_buffer;
    extern t_program *prog_buffer;

	i=0;
	j=0;
	flag_exit=0;
	rc=0;
	program=prog_buffer;
	program->size=0;
	//prog_buffer->size=0;

	rc = load_program();
	if (rc<0) {
		return (rc);
	}
	while (*(file_buffer+i) !=  '\0') {
		line[j] = *(file_buffer+i);
		if (*(file_buffer+i) == '\n') {
			line[j] = 0;
			remove_comment_in_line(line);
			if (check_valid_line(line)) {
				instruction = parse_and_save_instruction(line);
				if (check_exit_instruction(instruction)) {
					flag_exit=1;
				}
			}
			j=-1;
		}
	    j++;
		i++;
	}
	if (!flag_exit) {
		print_error(NOT_EXIT_COMMAND_ERROR, "");
		rc=-1;
	}
	return (rc);

}

void save_instruction(t_instruction *instruction) {
    
    extern t_program *prog_buffer;

    program->instructions[program->size]=instruction;
    program->size++;
    //prog_buffer->instructions[program->size]=instruction;
    //program->size++;
}


char * extract_name(char *line, char *buffer_name) {

	int i;
	
	i=0;
	while (*(line+i) !=  '\0') {
		buffer_name[i]=*(line+i);
		if (*(line+i) == ' ') {
			buffer_name[i]='\0';
			break;
		}
		i++;
	}
	return (buffer_name);

}

char * extract_type(char *line, char *buffer_type) {

	int i;
	int j;
	int start_type_flag;
	int end_type_flag;
	
	i=0;
	j=0;
	start_type_flag=0;
	end_type_flag=0;
	while (*(line+i) !=  '\0') {
		if (*(line+i)==' ') {
			start_type_flag=1;
			i++;
		}
		if (*(line+i)=='(') {
			end_type_flag=1;
		}
		if (start_type_flag) {
			buffer_type[j]=*(line+i);
			j++;
		}
		if (end_type_flag) {
			buffer_type[j-1]='\0';
			buffer_type=my_trim(buffer_type);
			break;
		}
		i++;
	}
	return (buffer_type);

}

char * extract_value(char *line, char *buffer_value) {

	int i;
	int j;
	int start_value_flag;
	int end_value_flag;
	
	i=0;
	j=0;
	start_value_flag=0;
	end_value_flag=0;
	while (*(line+i) !=  '\0') {
		if (*(line+i)=='(') {
			start_value_flag=1;
			i++;
		}
		if (*(line+i)==')') {
			end_value_flag=1;
		}
		if (start_value_flag) {
			buffer_value[j]=*(line+i);
			j++;
		}
		if (end_value_flag) {
			buffer_value[j-1]='\0';
			buffer_value=my_trim(buffer_value);
			break;
		}
		i++;

	}
	return (buffer_value);

}


t_instruction* parse_and_save_instruction(char *line) {

	t_instruction *instruction;
	instruction = parse_instruction(line);
	save_instruction(instruction);
	return (instruction);

}
t_instruction* parse_instruction(char *line) {

	t_instruction *instruction;
	char *buffer_name;
	char *buffer_type;
	char *buffer_value;

	buffer_name=allocate_char_buffer(1);
	buffer_type=allocate_char_buffer(1);
	buffer_value=allocate_char_buffer(1);
	instruction = (t_instruction*) malloc(sizeof(t_instruction));
	
	buffer_name=extract_name(line, buffer_name);
	buffer_type=extract_type(line, buffer_type);
	buffer_value=extract_value(line, buffer_value);
	
	instruction->name = buffer_name;
	instruction->arg_type = buffer_type;
	instruction->arg_value = buffer_value;

    return (instruction);

}


