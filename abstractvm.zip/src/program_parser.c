/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Helper functions to parse the program.
**      Empty lines and comment lines are removed.
**      Comment is removed if present in a line
*/

#include "program_parser.h"
#include "string_utils.h"
#include "memory_utils.h"
#include <stdlib.h>

void parse_program(char *program) {

	char line[1024];
	int i;
	int j;

	i=0;
	j=0;
	while (*(program+i) !=  '\0') {
		line[j] = *(program+i);
		if (*(program+i) == '\n') {
			line[j] = 0;
			validate_line(&line[0]);
			j=-1;
		}
	    j++;
		i++;
	}

}

void validate_line(char *line) {

	char *instruction;
	char *arg;

	instruction=allocate_char_buffer(1);
	arg=allocate_char_buffer(1);

	if ( (!is_empty_line(line)) && (!is_comment_line(line)) ) {
		clean_line(line);
		parse_instruction(line, instruction, arg);
		nb_instructions++;
	}
	
}

void clean_line(char *line) {

	int i;

	i=0;
	while (*(line+i) !=  '\0') {
		if (*(line+i) == ';') {
			*(line+i) = '\0';
		}
		i++;
	}

}

t_instruction* parse_instruction(char *line, char *instruction, char *arg) {

	int i;
	int j;
	int no_arg_flag;
	t_instruction *instruct;

	i=0;
	j=0;
	no_arg_flag=1;
	instruction=line;
	while (*(line+i) !=  '\0') {
		if (*(line+i) == ' ') {
			*(line+i)='\0';
			no_arg_flag=0;
			arg=remove_leading_spaces(line+i+1);
			break;
		}
		i++;
		j++;
	}
	instruct = (t_instruction*) malloc(sizeof(t_instruction));
	instruct->name = instruction;
	instruct->arg = arg;
	my_putstr(instruct->name);
    my_putchar('\n');
    my_putstr(instruct->arg);
    my_putchar('\n');
    return instruct;

}

void save_instruction(char *instruction, char *arg) {

	my_putstr("SAVE INSTRUCTION");
    my_putchar('\n');

    my_putstr(instruction);
    my_putchar('\n');
    my_putstr(arg);
    my_putchar('\n');

}

int is_comment_line(char *line) {

	if (*line == ';') {
		return (1);
	}
	return (0);

}

int is_empty_line(char *line) {

	int i;

	i=0;
	while (*(line+i) !=  '\0') {
		if (*(line+i) != ' ') {
			return (0);
		}
		i++;
	}
	return (1);
	
}

