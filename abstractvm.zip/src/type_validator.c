/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Functions needed to validate types
**         . Type must be known
**         . Type value must be numeric
*/

#include "type_validator.h"
#include "memory_utils.h"
#include "string_utils.h"

static char* type_set[11] = {
	INT8_TYPE,
	INT16_TYPE,
	INT32_TYPE,
	FLOAT_TYPE,
	DOUBLE_TYPE
};

int check_valid_type(const t_instruction *instruction) {

	int rc;
	int i;

	rc=0;
	
	if (is_empty(instruction->arg_type)) {
		return (1);
	}
	for (i=0;i<NB_TYPES;i++) {
		if (my_strcmp(instruction->arg_type,type_set[i])==0) {
			rc = 1;
			break;
		}
	}
	return rc;

}

int check_valid_value(const t_instruction *instruction) {

	int rc;

	rc = 0;
	if (is_empty(instruction->arg_type)) {
		rc = 1;
		return (rc);
	}
	rc = check_numeric_value(instruction->arg_value);
	return (rc);
	
}


int check_numeric_value(const char *str) {
	int i;

	i=0;
	while (*str != '\0') {
		if ((i==0) && (*str=='-')) {
			str++;
		}
        if ((*str != '.') && (*str < '0' || *str > '9')) {
            return (0);
        }
        str++;
        i++;
    }
    return (1);

}

int check_int_type(const char *arg_type) {

	int rc;
	int i;
	extern t_type *type_buffer;

    rc = 1;
	for (i=0; i<NB_TYPES; i++) {
		if (my_strcmp(type_buffer[i].name, arg_type)==0) {
			if (type_buffer[i].is_rational == 1) {
				rc = 0;
			}
			break;
		}

	}
	return (rc);

}

int check_rational_type(const char *arg_type) {

	int rc;
	int i;
	extern t_type *type_buffer;

    rc = 0;
	for (i=0; i<NB_TYPES; i++) {
		if (my_strcmp(type_buffer[i].name, arg_type)==0) {
			if (type_buffer[i].is_rational == 1) {
				rc = 1;
			}
			break;
		}

	}
	return (rc);

}









