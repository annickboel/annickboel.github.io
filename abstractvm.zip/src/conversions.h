#ifndef H_CONVERSION_UTILS
#define H_CONVERSION_UTILS

int string2int(char *);
char int8_to_char(char *);
char int2char(int);

#endif