/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Helper functions to load the abstractvm program.
*/

#include "program_loader.h"
#include "file_utils.h"

int load_program(void) {

	int rc;

	rc = read_file();
	return (rc);
	
}