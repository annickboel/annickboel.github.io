/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Functions to handle operators instructions
*/
#include "operators_handler.h"
#include "operators_validator.h"
#include "memory_utils.h"
#include "stack.h"

int handle_add(const char* arg_type, const char *arg_value) {

	int rc;
	int index;
	t_operator operator;
	extern t_stack *stack_buffer;
	extern t_operator* operator_buffer;

	rc = 0;
	index = find_operator_index(ADD_INSTRUCTION);
	operator=operator_buffer[index];
	if (!(validate_operands(&operator))){
		rc = -1;
	}
	return (rc);
}

int handle_sub(const char* arg_type, const char *arg_value) {

	int rc;
	t_operator operator;
	extern t_stack *stack_buffer;
	extern t_operator* operator_buffer;

	rc = 0;
	operator=operator_buffer[find_operator_index(SUB_INSTRUCTION)];
	if (!check_nb_operands_valid(&operator)) {
		rc = -1;
		return (rc);
	}
	return (rc);

}

int handle_mul(const char* arg_type, const char *arg_value) {

	int rc;
	t_operator operator;
	extern t_stack *stack_buffer;
	extern t_operator* operator_buffer;

	rc = 0;
	operator=operator_buffer[find_operator_index(MUL_INSTRUCTION)];
	if (!check_nb_operands_valid(&operator)) {
		rc = -1;
		return (rc);
	}
	return (rc);

}

int handle_div(const char* arg_type, const char *arg_value) {

	int rc;
	t_operator operator;
	extern t_stack *stack_buffer;
	extern t_operator* operator_buffer;

	rc = 0;
	operator=operator_buffer[find_operator_index(DIV_INSTRUCTION)];
	if (!check_nb_operands_valid(&operator)) {
		rc = -1;
		return (rc);
	}
	return (rc);

}

int handle_mod(const char* arg_type, const char *arg_value) {

	int rc;
	t_operator operator;
	extern t_stack *stack_buffer;
	extern t_operator* operator_buffer;

	rc = 0;
	operator=operator_buffer[find_operator_index(MOD_INSTRUCTION)];
	if (!check_nb_operands_valid(&operator)) {
		rc = -1;
		return (rc);
	}
	return (rc);

}
