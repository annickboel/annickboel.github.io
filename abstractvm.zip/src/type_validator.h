/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Functions needed to validate types
**         . Type must be known
**         . Type value must be numeric
*/

#ifndef H_TYPE_VALIDATOR
#define H_TYPE_VALIDATOR
#include "memory_utils.h"

int check_valid_type(const t_instruction *);
int check_valid_value(const t_instruction *);
int check_numeric_value(const char *);
int check_int_type(const char *);
int check_rational_type(const char *);

#endif