/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
**    Functions to handle the stack.
*/

#include <stdlib.h>
#include "stack.h"
#include "error_utils.h"
#include "memory_utils.h"
#include "string_utils.h"

int stack_add_item(t_stack_item *item) {

	extern t_stack *stack_buffer;
	int rc;

	rc = 0;
	stack_buffer->items[stack_buffer->size]=item;
	stack_buffer->size++;

	return (rc);

}

int stack_remove_item(void) {

	int rc;
	extern t_stack *stack_buffer;
   
    rc = 0;
    int i;
	if (stack_buffer->size == 0) {
		print_error(STACK_IS_EMPTY_ERROR, "");
		rc = -1;
	}
	for (i=1;i<stack_buffer->size;i++) {
		stack_buffer->items[i-1]=stack_buffer->items[i];
	}
	stack_buffer->items[i]=NULL;
	stack_buffer->size--;

	return (rc);

}

