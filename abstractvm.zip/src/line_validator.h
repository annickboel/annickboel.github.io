/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Functions needed to valiadate program lines
**     		. Comment lines and empty lines are not valid
**     		. Comment at the end of a line will be removed
*/

#ifndef H_LINE_VALIDATOR
#define H_LINE_VALIDATOR
#include "memory_utils.h"

int check_comment_line(const char *line);
int check_valid_line(const char* line);
int check_empty_line(const char *line); 
void remove_comment_in_line(char *line);

#endif