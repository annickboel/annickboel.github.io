/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Functions to interpret the program.
*/

#ifndef H_PROGRAM_INTERPRETOR
#define H_PROGRAM_INTERPRETOR

#include "memory_utils.h"

void init_handlers(void);
int interpret_program(void);
int interpret_instruction(const t_instruction *);
int find_handler(const t_instruction *instruction);

#endif