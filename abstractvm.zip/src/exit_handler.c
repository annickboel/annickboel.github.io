/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Function to handle the exit instruction
*/
#include "exit_handler.h"

int  handle_exit(const char * arg_type, const char *arg_value) {

	int rc;

	rc = -1;
	return (rc);

}
