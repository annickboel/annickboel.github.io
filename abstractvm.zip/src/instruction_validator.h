/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Functions needed to valiadate instructions
*/

#ifndef H_INSTRUCTION_VALIDATOR
#define H_INSTRUCTION_VALIDATOR
#include "memory_utils.h"

int check_known_instruction(const t_instruction *);
int check_exit_instruction(const t_instruction *);

#endif