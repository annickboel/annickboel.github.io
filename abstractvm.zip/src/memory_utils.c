/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Utility functions to handle memory.
*/
#include <stdlib.h>
#include "memory_utils.h"

char *filename = NULL;
t_stack* stack_buffer = NULL;
char *file_buffer = NULL;
t_program *prog_buffer = NULL;
t_type *type_buffer = NULL;
t_operator* operator_buffer = NULL;

int allocate_memory(void) {

	int rc;

	rc = 0;
	if (!(init_stack_buffer(STACK_INITIAL_SIZE) && 
		init_file_buffer(MAX_FILE_SIZE) &&
		init_prog_buffer(MAX_PROG_SIZE) && 
		init_operator_buffer(NB_TYPES) &&
		init_type_buffer(NB_TYPES))) {
		rc = -1;
	}
	return (rc);

}

void free_memory(void) {

	free(filename);
	free(file_buffer);
	free(prog_buffer);
	free(type_buffer);
	free(operator_buffer);

}

int init_operator_buffer(int size) {
	int rc;

	rc = 1;
    operator_buffer = (t_operator *) malloc(NB_OPERATORS * sizeof(t_operator));
    if (operator_buffer == NULL) {
    	rc = 0;
    }
    operator_buffer[0].name = ADD_INSTRUCTION;
    operator_buffer[0].nb_args = 2;
    operator_buffer[0].index = 0;
    operator_buffer[1].name = SUB_INSTRUCTION;
    operator_buffer[1].nb_args = 2;
    operator_buffer[0].index = 1;
    operator_buffer[2].name = MUL_INSTRUCTION;
    operator_buffer[2].nb_args = 2;
    operator_buffer[0].index = 2;
    operator_buffer[3].name = DIV_INSTRUCTION;
    operator_buffer[3].nb_args = 2;
    operator_buffer[0].index = 3;
    operator_buffer[4].name = MOD_INSTRUCTION; 
    operator_buffer[4].nb_args = 2;
    operator_buffer[0].index = 4;
	return (rc);
}



char * allocate_char_buffer(int size) {

  char *ptr;

  ptr = (char *) malloc(size * sizeof(char));
  *ptr='\0';
  return (ptr);

}

void free_buffer(char *ptr) {

  free(ptr);

}

int init_type_buffer(int size) {

	int rc;
	rc = 1;
	type_buffer=(t_type *) malloc(NB_TYPES * sizeof(t_type));
	if (type_buffer == NULL) {
		rc = 0;
	}
	type_buffer[0].name = INT8_TYPE;
    type_buffer[0].precision = 0;
    type_buffer[0].is_rational = 0;
    type_buffer[1].name = INT16_TYPE;
    type_buffer[1].precision = 1;
    type_buffer[1].is_rational = 0;
    type_buffer[2].name = INT32_TYPE;
    type_buffer[2].precision = 2;
    type_buffer[2].is_rational = 0;
    type_buffer[3].name = FLOAT_TYPE;
    type_buffer[3].precision = 3;
    type_buffer[3].is_rational = 1;
    type_buffer[4].name = DOUBLE_TYPE;
    type_buffer[4].precision = 4;
    type_buffer[4].is_rational = 1;
	return (rc);
}

int init_file_buffer(int size) {

	int rc;

	rc = 1;
 	file_buffer = allocate_char_buffer(size);
 	if (file_buffer == NULL) {
 		rc = 0;
 	}
 	return (rc);

 }

 int  init_prog_buffer(int size) {
    
    int rc;
    
    rc = 1;
 	prog_buffer = (t_program *) malloc(sizeof(t_program));
 	if (prog_buffer == NULL) {
 		rc = 0;
 		return (rc);
 	}
 	prog_buffer->instructions=(t_instruction **) malloc(MAX_PROG_SIZE * sizeof(t_instruction));
 	if (prog_buffer->instructions == NULL) {
 		rc = 0;
 		return (rc);
 	}
 	prog_buffer->size=0;
 	return (rc);

 }

 int init_stack_buffer(int size) {

 	int rc;

    rc = 1;
 	stack_buffer = (t_stack *) malloc(sizeof(t_stack));
 	if (stack_buffer == NULL) {
 		rc = 0;
 		return (rc);
 	}
 	stack_buffer->items = (t_stack_item **) malloc(STACK_MAX_SIZE * sizeof(t_stack));
 	if (stack_buffer->items == NULL) {
 		rc = 0;
 		return (rc);
 	}
 	stack_buffer->size=size;
 	return (rc);

 }

 t_stack_item* allocate_stack_item(void) {

 	t_stack_item *stack_item;
 	stack_item = (t_stack_item *) malloc(sizeof(t_stack_item));
 	return (stack_item);

 }
