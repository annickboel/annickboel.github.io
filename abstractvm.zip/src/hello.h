/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		No file there, just an etna header example
*/

#ifndef H_HELLO
#define H_HELLO

void Hello(void);

#endif
