/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Functions needed to valiadate instructions
*/

#include "instruction_validator.h"
#include "memory_utils.h"
#include "string_utils.h"
//#include "error_utils.h"

static char* instruction_set[11] = {
	PUSH_INSTRUCTION,
	POP_INSTRUCTION,
	ADD_INSTRUCTION,
	SUB_INSTRUCTION,
	MUL_INSTRUCTION,
	DIV_INSTRUCTION,
	MOD_INSTRUCTION,
	ASSERT_INSTRUCTION,
	DUMP_INSTRUCTION,
	PRINT_INSTRUCTION,
	EXIT_INSTRUCTION,
};

int check_known_instruction(const t_instruction *instruction) {

	int rc;
	int i;

	rc=0;
	for (i=0;i<NB_INST;i++) {
		if (my_strcmp(instruction->name,instruction_set[i])==0) {
			rc = 1;
			break;
		}
	}
	return rc;
}

int check_exit_instruction(const t_instruction *instruction) {

	int rc;

	rc = 0;
	if (my_strcmp(instruction->name,"exit") == 0) {
		rc = 1;
	}
	return (rc);

}




