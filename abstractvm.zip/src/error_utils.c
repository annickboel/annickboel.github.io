/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
**    Utility functions to handle errors.
*/

#include "error_utils.h"
#include "string_utils.h"

void print_error(const char * message, const char * arg) {

	my_putstr(message);
	my_putstr(arg);
	my_putchar('\n');

}

void usage(void) {
	
	my_putstr("./abstractvm [PROGNAME]\n");

}