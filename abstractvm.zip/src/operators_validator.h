/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Functions to validate operands of a given opearor
*/
#ifndef H_OPERANDS_VALIDATOR
#define H_OPERANDS_VALIDATOR
#include "memory_utils.h"

int find_operator_index(char *);
int validate_operands(const t_operator *);
int check_nb_operands_valid(const t_operator *);
int check_operand_type_valid(const t_operator *, const t_stack_item *);

#endif