/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Functions needed to valiadate syntax
*/

#ifndef H_SYNTAX_VALIDATOR
#define H_SYNTAX_VALIDATOR
#include "memory_utils.h"

int check_valid_syntax(t_instruction *); 

#endif