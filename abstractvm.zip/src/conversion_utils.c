/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Conversion functions
*/
#include <stdio.h>
#include "string_utils.h"
#include "memory_utils.h"
#include "error_utils.h"

const char * get_greatest_precision(const char *type1, const char *type2) {

	int index1;
	int index2;
	const char *type;
	extern t_type *type_buffer;
	int i;

	for (i=0;i<NB_TYPES;i++) {
		if (my_strcmp(type1, type_buffer[i].name)==0) {
			index1 = i;
		}
	}
	for (i=0;i<NB_TYPES;i++) {
		if (my_strcmp(type2, type_buffer[i].name)==0) {
			index2 = i;
		}
	}
	if (index1 == index2) {
		type = type1;
	}
	else {
		type = (index1<index2) ? type2 : type1;
	}
	return (type);

}

/*int string2int(char * str) {

	int result;
	int i;

    i=0;
	while (*(str+i)=='\0') {
		result = result * 10 + ( str[i] - '0' );
	}
	return (result);
}

int int8_to_char(char *str) {

	int result;
	int i;

    i=0;
    my_putstr("int8_to_char");
    my_putchar('\n');
    my_putstr(str);
	while (*(str+i)=='\0') {
		my_putchar(*(str+i));
		my_putchar('\n');
		result = result * 10 + ( str[i] - '0' );
		printf("%d\n", result);
	}
	return result;

}


char int2char(int a_int) {

	return a_int+'0';
}*/