/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Utility functions to handle errors.
*/

#ifndef H_ERROR_UTILS
#define H_ERROR_UTILS

#define OPEN_FILE_ERROR "E001 - Cannot open file: "
#define CLOSE_FILE_ERROR "E002 - Cannot close file: "
#define MEMORY_ALLOCATION_ERROR "E003 - Unable to allocate memory"
#define MEMORY_FREE_ERROR "E004 - Unable to free memory"
#define NOT_EXIT_COMMAND_ERROR "E005 - The program has no exit command"
#define UNKNOWN_INSTRUCTION_ERROR "E006 - Unknown instruction: "
#define INVALID_TYPE_ERROR "E007 - Invalid type: "
#define STACK_IS_EMPTY_ERROR "E008 - Stack is empty"
#define NB_OPERANDS_ERROR "E009 - Invalid number of operands for operator: "
#define NOT_PRINTABLE_VALUE_ERROR "E010 - Value type is not printable"
#define INVALID_OPERAND_TYPE_ERROR "E011 - Operand type is invalid for operator: "


void print_error(const char *, const char *);
void usage(void);

#endif