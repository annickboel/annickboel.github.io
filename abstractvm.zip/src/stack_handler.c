/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Functions to manipulate the stack
*/

#include "stack_handler.h"
#include "memory_utils.h"
#include "string_utils.h"
#include "error_utils.h"
#include "conversion_utils.h"
#include "stack.h"
#include <stdlib.h>
#include <stdio.h>


int handle_push(const char* arg_type, const char *arg_value) {

	int rc;
	t_stack_item *item;


    rc = 0;
    item = NULL;
	item = allocate_stack_item();
	if (item == NULL) {
		rc = -1;
		return (rc);
	}
	item->type = arg_type;
	item->value = arg_value;
	rc = stack_add_item(item);
	return (rc);

}

int handle_pop(const char* arg_type, const char *arg_value) {

	int rc;

	rc = stack_remove_item();
	return (rc);

}

int handle_assert(const char* arg_type, const char *arg_value) {

	int rc;

	rc = 0;
	my_putstr("ASSERT ");
	my_putstr(arg_value);
	my_putchar('\n');
	return (rc);

}

int handle_dump(const char* arg_type, const char *arg_value) {

	int rc;
	int i;
	extern t_stack *stack_buffer;

	rc = 0;
	for (i=0; i<stack_buffer->size; i++) {
		t_stack_item *item = stack_buffer->items[i];
		my_putstr(item->value);
		my_putchar('\n');
	}
	return (rc);
}

int handle_print(const char* arg_type, const char *arg_value) {

	int rc;
	extern t_stack *stack_buffer;

	rc = 0;
	my_putstr("PRINT ");
	my_putchar('\n');
	if (stack_buffer->size == 0) {
		print_error(STACK_IS_EMPTY_ERROR, "");
		rc = (-1);
		return (rc);
	}
	t_stack_item *item = stack_buffer->items[0];
	if (my_strcmp(item->type, "int8") !=0 ) {
		print_error(NOT_PRINTABLE_VALUE_ERROR, "");
		rc = (-1);
		return (rc);
	}
	//int i = int8_to_char(arg_value);
	//float f=10.5;
    //float f = 10.5 % 2;
	return (rc);

}
