/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Functions needed to valiadate program lines
**     		. Comment lines and empty lines are not valid
**     		. Comment at the end of a line will be removed
*/

#include "line_validator.h"
#include "memory_utils.h"
#include "string_utils.h"
#include "error_utils.h"

int check_comment_line(const char *line) {

	if (*line == ';') {
		return (1);
	}
	return (0);

}

int check_valid_line(const char *line) {

	if (check_comment_line(line) || check_empty_line(line)) {
		return (0);
	}
	return (1);

}

int check_empty_line(const char *line) {

	int i;

	i=0;
	while (*(line+i) !=  '\0') {
		if (*(line+i) != ' ') {
			return (0);
		}
		i++;
	}
	return (1);
	
}

void remove_comment_in_line(char *line) {

	int i;

	i=0;
	while (*(line+i) !=  '\0') {
		if (*(line+i) == ';') {
			*(line+i) = '\0';
		}
		i++;
	}

}





