/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Functions to handle operator instructions
*/
#ifndef H_OPERATORS_HANDLER
#define H_OPERATORS_HANDLER
#include "memory_utils.h"

int handle_add(const char*, const char *);
int handle_sub(const char*, const char *);
int handle_mul(const char*, const char *);
int handle_div(const char*, const char *);
int handle_mod(const char*, const char *);

#endif