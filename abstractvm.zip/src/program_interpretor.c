/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Functions to interpret the program.
*/
#include "string_utils.h"
#include "error_utils.h"
#include "memory_utils.h"
#include "program_interpretor.h"
#include "syntax_validator.h"
#include "stack_handler.h"
#include "operators_handler.h"
#include "exit_handler.h"
#include "program_parser.h"

static t_handler handlers[NB_INST];

void init_handlers(void) {

	handlers[0].name = PUSH_INSTRUCTION;
	handlers[0].func = handle_push;
	handlers[1].name = POP_INSTRUCTION;
	handlers[1].func = handle_pop;
	handlers[2].name = ADD_INSTRUCTION;
	handlers[2].func = handle_add;
	handlers[3].name = SUB_INSTRUCTION;
	handlers[3].func = handle_sub;
	handlers[4].name = MUL_INSTRUCTION;
	handlers[4].func = handle_mul;
	handlers[5].name = DIV_INSTRUCTION;
	handlers[5].func = handle_div;
	handlers[6].name = MOD_INSTRUCTION;
	handlers[6].func = handle_mod;
	handlers[7].name = ASSERT_INSTRUCTION;
	handlers[7].func = handle_assert;
	handlers[8].name = DUMP_INSTRUCTION;
	handlers[8].func = handle_dump;
	handlers[9].name = PRINT_INSTRUCTION;
	handlers[9].func = handle_print;
	handlers[10].name = EXIT_INSTRUCTION;
	handlers[10].func = handle_exit;
}

int interpret_program(void) {

	int rc;
	int i;
	extern char *file_buffer;
	extern t_program *prog_buffer;
	extern t_stack *stack;

	rc = 0;
	i=0;
	init_handlers();
	rc=parse_program();
	if (rc < 0) {
		return (rc);
	}
	for (i=0;i<prog_buffer->size;i++) {
		t_instruction *instruction = prog_buffer->instructions[i];
		rc = interpret_instruction(instruction);
		if (rc < 0) {
			break;
		}
	}
	return (rc);

}

int find_handler(const t_instruction *instruction) {

	int i;

	i=0;
	for (i=0;i<NB_INST;i++) {
		if (my_strcmp(instruction->name, handlers[i].name)==0) {
			break;
		}
	}
	return (i);
}

int interpret_instruction(const t_instruction *instruction) {
	
	int rc;
	t_handler handler;
	rc=0;
	handler = handlers[find_handler(instruction)];
	rc = handler.func(instruction->arg_type, instruction->arg_value);
	return (rc);
}





