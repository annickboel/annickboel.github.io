/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Utility functions to handle files.
*/

#ifndef H_FILE_UTILS
#define H_FILE_UTILS

int read_file(void);

#endif