/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Utility functions to handle memory.
*/

#ifndef H_MEMORY_UTILS
#define H_MEMORY_UTILS

#define MAX_FILE_SIZE 5000
#define MAX_PROG_SIZE 500
#define STACK_INITIAL_SIZE 0
#define STACK_MAX_SIZE 500
#define NB_INST 11
#define NB_TYPES 5
#define NB_OPERATORS 5

#define PUSH_INSTRUCTION "push"
#define POP_INSTRUCTION "pop"
#define DUMP_INSTRUCTION "dump"
#define PRINT_INSTRUCTION "print"
#define ASSERT_INSTRUCTION "assert"
#define ADD_INSTRUCTION "add"
#define SUB_INSTRUCTION "sub"
#define MUL_INSTRUCTION "mul"
#define DIV_INSTRUCTION "div"
#define MOD_INSTRUCTION "mod"
#define EXIT_INSTRUCTION "exit"

#define INT8_TYPE "int8"
#define INT16_TYPE "int16"
#define INT32_TYPE "int32"
#define FLOAT_TYPE "float"
#define DOUBLE_TYPE "double"


typedef struct instruction {
	const char *name;
	char *arg_type;
	char *arg_value;
} t_instruction;

typedef struct type {
	const char *name;
	int precision;
	int is_rational;
} t_type;

typedef struct operator {
	const char *name;
	int index;
	int nb_args;
} t_operator;

typedef struct program {
	t_instruction **instructions;
	int size;
} t_program;

typedef struct handler {
	const char *name;
	int (*func)(const char*, const char*);
} t_handler;

typedef struct stack_item {
	const char *type;
	const char *value;
} t_stack_item;

typedef struct stack {
	t_stack_item** items;
	int size;

} t_stack;

int allocate_memory(void);
void free_memory(void);
char * allocate_char_buffer(int);
void free_buffer(char *);
int init_file_buffer(int);
int init_prog_buffer(int);
int init_stack_buffer(int);
int init_operator_buffer(int);
t_stack_item * allocate_stack_item(void);
int init_type_buffer(int);

#endif