/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Utility functions to handle strings.
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "string_utils.h"

void my_putchar(char c) {

  write(1, &c, 1);

}


void my_putstr(char *str) {
  int i;

  i = 0;
  while (str[i] != '\0') {
      my_putchar(str[i]);
      i++;
   }
}


char* remove_leading_spaces(char *str) {
  
  int i;
  char *start;

  i = 0;
  start=str;
  while (str[i] != '\0') {
  	  if (*(str+i) == ' ') {
  	  	start++;
  	  }
      i++;
   }
   return start;
}


char* remove_trailing_spaces(char *str) {
  
   return str;
}