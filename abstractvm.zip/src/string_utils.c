/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Utility functions to handle strings.
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "string_utils.h"

void my_putchar(const char c) {

  write(1, &c, 1);

}


void my_putstr(const char *str) {
  int i;

  i = 0;
  while (str[i] != '\0') {
      my_putchar(str[i]);
      i++;
   }
}


char* remove_leading_spaces(char *str) {
  
  int i;
  char *start;

  i = 0;
  start=str;
  while (*(str+i) != '\0') {
  	  if (*(str+i) == ' ') {
  	  	start++;
  	  }
  	  else {
  	  	break;
  	  }
      i++;
   }
   return (start);
}


char* remove_trailing_spaces(char *str) {

  int i;

  i = 0;
  while (*(str+i) != '\0') {
  	  if (*(str+i) == ' ') {
  	  	*(str+i) = '\0';
  	  	break;
  	  }
      i++;
   }
   return (str);

}

char* my_trim(char *str) {

	str=remove_leading_spaces(str);
	str=remove_trailing_spaces(str);
	return (str);

}

int	my_strcmp(const char *s1, const char *s2) {

  int i;

  i = 0;
  while ((s1[i] == s2[i]) && (s1[i] != '\0') && (s2[i] != '\0')) {
      i++;
  }
  return (s1[i] - s2[i]);

}

int is_empty(const char * str) {

	int rc;
	int i;

    i=0;
    rc=1;
	while (*(str+i)!='\0') {
		i++;
	}
	if (i-1>0) {
		rc=0;
	}

	return (rc);

}



