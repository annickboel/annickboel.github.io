/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Utility functions to handle strings.
*/

#ifndef H_STRING_UTILS
#define H_STRING_UTILS

void my_putchar(const char);
void my_putstr(const char *);
int my_strcmp(const char *, const char *);
char* remove_leading_spaces(char *);
char* remove_trailing_spaces(char *);
char* my_trim(char *);
int is_empty(const char *);

#endif