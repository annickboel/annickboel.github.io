/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Utility functions to handle strings.
*/

#ifndef H_STRINGUTILS
#define H_STRINGUTILS

void my_putchar(char);
void my_putstr(char *);
char* remove_leading_spaces(char *str);


#endif