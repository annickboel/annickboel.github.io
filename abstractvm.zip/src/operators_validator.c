/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Functions to validate operands for a given operator
*/
#include "operators_validator.h"
#include "type_validator.h"
#include "memory_utils.h"
#include "string_utils.h"
#include "error_utils.h"
#include "stack.h"

int validate_operands(const t_operator *operator) {

	int rc;
	int i;
	extern t_stack *stack_buffer;

	rc = 1;
	i = 0;
	if (!(check_nb_operands_valid(operator))) {
		rc = 0;
		return (rc);
	}
	for (i=0; i<operator->nb_args; i++) {
		t_stack_item *item = stack_buffer->items[i];
		if (!(check_operand_type_valid(operator, item))) {
			rc = -1;
			break;
		}
	}
	return (rc);
}

int check_nb_operands_valid(const t_operator *operator) {

	int rc;
	extern t_stack *stack_buffer;
	rc=1;
	
	if (stack_buffer->size < operator->nb_args)  {
		print_error(NB_OPERANDS_ERROR, operator->name);
		rc = 0;
		return (rc);
	}

	return (rc);
}

int check_operand_type_valid(const t_operator *operator, const t_stack_item *item) {

	int rc;
	int i;

	rc=1;
	i=0;
	my_putstr(operator->name);
	my_putstr(item->type);
	switch (operator->index) {
		case 0:
			my_putstr("ADD");
			break;
		case 1:
			my_putstr("SUB");
			break;
		case 2:
			my_putstr("MUL");
			break;
		case 3:
			my_putstr("DIV");
			break;
		case 4:
			my_putstr("MOD");
			if (check_rational_type(item->type)) {
				rc = 0;
				print_error(INVALID_OPERAND_TYPE_ERROR, operator->name);
			}
			break;
	}
	return (rc);
}

int find_operator_index(char *name) {

	extern t_operator* operator_buffer;
	int i;

	for (i=0; i<NB_OPERATORS; i++) {
		if (my_strcmp(operator_buffer[i].name, name)==0) {
			operator_buffer[i].index=i;
			break;
		}
	}
	return (i);
}

