/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
**    Functions to handle files.
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "file_utils.h"
#include "error_utils.h"
#include "memory_utils.h"

int read_file(void) {

  int fd;
  int rc;
  int size;
  extern char *filename;
  extern char *file_buffer;

  fd = open(filename, O_RDONLY);
  if (fd == -1) {
  	  print_error(OPEN_FILE_ERROR, filename);
      return (fd);
  }
  //size = read(fd, pbuf, MAX_FILE_SIZE);
  size = read(fd, file_buffer, MAX_FILE_SIZE);
  file_buffer[size] = '\0';
  rc = close(fd);
  if (rc == -1) {
    print_error(CLOSE_FILE_ERROR, filename);
    return (rc); 
  }
  return (rc);
 
}