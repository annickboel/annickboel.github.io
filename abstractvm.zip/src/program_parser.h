/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Helper functions to parse the program
**      	. Empty lines and comment lines are removed
**      	. Comment is removed if present in a line
**      	. An instruction structure is initialized for each valid line
*/

#ifndef H_PROGRAM_PARSER
#define H_PROGRAM_PARSER
#include "memory_utils.h"

int parse_program(void);
void save_instruction(t_instruction*);
t_instruction * parse_instruction(char *);
t_instruction * parse_and_save_instruction(char *);
char * extract_name(char *, char *);
char * extract_type(char *, char *);
char * extract_value(char *, char *);

#endif