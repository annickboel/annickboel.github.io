/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Functions to parse the program.
*/

#ifndef H_PRGMPARSER
#define H_PRGMPARSER

#define MAX_SIZE 5000

static int nb_instructions=0;

typedef struct instruction {
	char *name;
	char *arg;
} t_instruction;

typedef struct program {
	char **instructions;
} t_program;

void parse_program(char *);
void validate_line(char *);
int is_empty_line(char *);
int is_comment_line(char *);
void clean_line(char *);
t_instruction* parse_instruction(char *, char *, char *);
void save_instruction(char *, char *);

#endif