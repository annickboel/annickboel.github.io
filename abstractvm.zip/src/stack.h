/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
**    Functions to handle the stack.
*/




void init_stack(void);