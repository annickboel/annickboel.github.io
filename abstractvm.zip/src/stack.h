/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
**    Functions to handle the stack.
*/
#ifndef H_STACK
#define H_STACK
#include "memory_utils.h"

int stack_add_item(t_stack_item *);
int stack_remove_item(void);

#endif
