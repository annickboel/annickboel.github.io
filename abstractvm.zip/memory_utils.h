/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Utility functions to handle memory.
*/

#ifndef H_MEMUTILS
#define H_MEMUTILS

char * allocate_char_buffer(int);
void free_buffer(char *ptr);

#endif