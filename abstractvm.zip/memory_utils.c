/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Utility functions to handle memory.
*/
#include <stdlib.h>
#include "file_utils.h"

char * allocate_char_buffer(int size) {

  char *ptr;

  ptr = (char *) malloc(size * sizeof(char));
  return (ptr);

}

void free_buffer(char *ptr) {

  free(ptr);

}