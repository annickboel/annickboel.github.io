/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Functions to parse the program.
*/

#ifndef H_PRGMPARSER
#define H_PRGMPARSER

#define MAX_SIZE 5000

void parse_program(char *);
void parse_line(char *);
int is_empty_line(char *);
int is_comment_line(char *);
void extract_instruction(char *);

#endif