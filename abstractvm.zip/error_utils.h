/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Utility functions to handle errors.
*/

#ifndef H_ERRORUTILS
#define H_ERRORUTILS

#define OPEN_FILE_ERROR "CANNOT OPEN FILE "
#define CLOSE_FILE_ERROR "CANNOT CLOSE FILE "

void print_error(char *, char *);
int handle_error(char *, char *, int);
void usage(void);

#endif