/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Utility functions to handle files.
*/

#ifndef H_FILEUTILS
#define H_FILEUTILS

#define MAX_SIZE 5000

int read_file(char *, char *);

#endif