/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Program entry point
*/


#include "program_loader.h"
#include "memory_utils.h"
#include "error_utils.h"
#include "program_parser.h"

int main(int argc, char **argv) {

	char *filename;
	char *buffer;
	int rc;
	rc = 0;

	if (argc < 2) {
        usage();
        rc = -1;
        return (rc);
    }
    filename = argv[1];
    buffer = allocate_char_buffer(MAX_SIZE);
    rc = load_program(filename, buffer);
    if (rc < 0) {
		return (rc);
	}
	parse_program(buffer);

	return (rc);
}
