/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
**    Functions to handle the stack.
*/

#define MAX_SIZE 100

typedef struct instruction {
	char *name;
	char *type ;
	char *value;
} t_instruction;


void init_stack(void);