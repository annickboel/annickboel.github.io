/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Helper functions to parse the program.
*/

#include "program_parser.h"
#include "syntax_validator.h"
#include "string_utils.h"

void parse_program(char *ptr) {

	char line[1024];
	int i;
	int j;

	i=0;
	j=0;
	while (*(ptr+i) !=  '\0') {
		line[j] = *(ptr+i);
		if (*(ptr+i) == '\n') {
			line[j] = 0;
			parse_line(&line[0]);
			j=-1;
		}
	    j++;
		i++;
	}

}

void parse_line(char *ptr) {

	char line[1024];
	int i;
	int j;

	if ( (!is_empty_line(ptr)) && (!is_comment_line(ptr)) ) {
		extract_instruction(ptr);
		is_valid_instruction(ptr);
	}
	
}


void extract_instruction(char *ptr) {

	int i;

	i=0;
	while (*(ptr+i) !=  '\0') {
		if (*(ptr+i) == ';') {
			*(ptr+i) = '\0';
		}
		i++;
	}

}


int is_comment_line(char *ptr) {

	if (*ptr == ';') {
		return (1);
	}
	return (0);

}

int is_empty_line(char *ptr) {

	int i;

	i=0;
	while (*(ptr+i) !=  '\0') {
		if (*(ptr+i) != ' ') {
			return (0);
		}
		i++;
	}
	return (1);
	
}

