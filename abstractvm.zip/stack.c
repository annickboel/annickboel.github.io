/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
**    Functions to handle the stack.
*/

#include "stack.h"

void init_stack(void) {

}