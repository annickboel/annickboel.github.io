/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
**    Functions to handle files.
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "file_utils.h"
#include "error_utils.h"

int read_file(char *filename, char *pbuf) {

  int fd;
  int rc;
  int size;

  rc = 0;
  fd = open(filename, O_RDONLY);
  if (fd == -1) {
  	  rc = handle_error(OPEN_FILE_ERROR, filename, -1);
      return (rc);
  }
  size = read(fd, pbuf, MAX_SIZE);
  pbuf[size] = 0;
  rc = close(fd);
  if (rc == -1) {
    rc = handle_error(CLOSE_FILE_ERROR, filename, -1);
    return (rc); 
  }
  return (rc);
 
}