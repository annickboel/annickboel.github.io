/*
** ETNA PROJECT, 2019
** TIC-CRW2 / AbstractVM
** File description:
** 		Helper functions to load the abstractvm program.
*/

#ifndef H_PRGMLOADER
#define H_PRGMLOADER



int load_program(char *, char *);

#endif